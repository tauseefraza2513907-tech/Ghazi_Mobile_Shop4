# Ghazi Mobile Shop Website

Website for Ghazi Mobile Shop, Main Bazar Khaki Lakhi, Tehsil Shorkot (Jhang).
Phone / WhatsApp: 0309-9693921

## Run on your computer
```
pip install -r requirements.txt
streamlit run app.py
```

## Files
- `app.py` : Streamlit app
- `index.html` : the website design (edit this to change text, colours, phone number)
- `requirements.txt` : Python packages
